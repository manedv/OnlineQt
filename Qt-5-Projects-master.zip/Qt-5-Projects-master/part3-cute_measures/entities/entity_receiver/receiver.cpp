#include "receiver.h"

entities::Receiver::Receiver(QObject *parent) : QObject(parent)
{

}
