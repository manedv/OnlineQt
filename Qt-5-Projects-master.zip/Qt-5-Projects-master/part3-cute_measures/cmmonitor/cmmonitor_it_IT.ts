<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="8"/>
        <source>CM Monitor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
