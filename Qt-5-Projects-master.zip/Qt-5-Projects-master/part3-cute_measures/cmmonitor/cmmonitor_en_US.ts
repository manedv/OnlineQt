<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="8"/>
        <source>CM Monitor</source>
        <translation>Cute Measures Monitor</translation>
    </message>
</context>
</TS>
