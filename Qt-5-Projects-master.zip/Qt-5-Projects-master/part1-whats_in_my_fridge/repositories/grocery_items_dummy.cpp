#include "grocery_items_repo.h"
#include "grocery_items_dummy.h"

namespace repositories {

GroceryItemsDummy::GroceryItemsDummy(QObject *parent) : GroceryItemsRepo(parent)
{

}

}
